package br.com.zup.SistemaBibliotecaSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBibliotecaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
